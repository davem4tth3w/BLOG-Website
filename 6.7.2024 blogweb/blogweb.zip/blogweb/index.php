<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>homepage</title>

  <link rel="stylesheet" href="bootstrap-5.0.2-dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="bootstrap-5.0.2-dist/bootstrap-icons-1.11.3/font/bootstrap-icons.min.css">
  <link rel="stylesheet" href="css/homepage.css">
  <style>
    <?php include"css/homepage.css"?>
</style>
</head>

  <body>

  <?php include 'navbar.php'?>
    <div class="body-container">

      <div class="contents">
        <div class="title">
          <div class="texts">
          <p>Welcome to </p>
          <h1>BSCS Educational Tour </h1>
          <p class="title_msg">Witness the remarkable fusion of learnings and adventure like never <br>before as we unveil our unforgettable BSCS Tour 2024 experience</p>
          </div>

        </div>

        <div class="line1">
        <h3>Highlights of [no. of days] Industry Visit</h3>
        </div>
        
      </div>

      <div class="footer">
        <h5>FOOTER</h5>
      </div>
      

    </div>

    
  </body>
</html>
