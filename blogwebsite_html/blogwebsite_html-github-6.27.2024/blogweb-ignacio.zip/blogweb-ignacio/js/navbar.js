
  document.getElementById('searchIcon').addEventListener('click', function() {
    document.getElementById('searchContainer').style.display = 'flex';
  });

  document.getElementById('searchIconDesktop').addEventListener('click', function() {
    document.getElementById('searchContainer').style.display = 'flex';
  });

  document.getElementById('closeButton').addEventListener('click', function() {
    document.getElementById('searchContainer').style.display = 'none';
  });
