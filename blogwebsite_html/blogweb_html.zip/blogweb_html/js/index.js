document.addEventListener('scroll', function() {
    const scrollPosition = window.pageYOffset;
    const background = document.querySelector('.background-container');
    const newSize = 100 - (scrollPosition * 0.1); // Adjust the 0.1 to increase or decrease the shrink rate

    background.style.backgroundSize = newSize + '%';
});
