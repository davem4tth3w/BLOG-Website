<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>navbar</title>

  <link rel="stylesheet" href="bootstrap-5.0.2-dist/css/bootstrap.min.css">

  <link rel="stylesheet" href="css/homepage.css">
  <link rel="stylesheet" href="bootstrap-5.0.2-dist/bootstrap-icons-1.11.3/font/bootstrap-icons.min.css">
</head>
<body>
<h2>Blog page</h2>
</body>
</html>
