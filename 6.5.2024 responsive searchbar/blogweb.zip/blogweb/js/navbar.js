document.addEventListener('DOMContentLoaded', function () {
  const searchButton = document.getElementById('searchButton');
  const closeButton = document.getElementById('closeButton');
  const searchInput = document.getElementById('searchInput');

  searchButton.addEventListener('click', function () {
    searchInput.style.display = 'block';
    closeButton.style.display = 'block';
    searchButton.style.display = 'none';
  });

  closeButton.addEventListener('click', function () {
    searchInput.style.display = 'none';
    closeButton.style.display = 'none';
    searchButton.style.display = 'block';
  });
});
