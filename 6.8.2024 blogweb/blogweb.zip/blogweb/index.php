<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>homepage</title>

  <link rel="stylesheet" href="bootstrap-5.0.2-dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="bootstrap-5.0.2-dist/bootstrap-icons-1.11.3/font/bootstrap-icons.min.css">
  <link rel="stylesheet" href="css/homepage.css">
  <style>
    <?php include"css/homepage.css"?>
</style>
</head>

  <body>

  <?php include 'navbar.php'?>
    <div class="body-container">

      <div class="contents">

        <div class="title" id="animated-bg">
          <div class="texts">
            <p>Welcome to </p>
            <h1>BSCS Educational Tour </h1>
            <p class="title_msg">Witness the remarkable fusion of learnings and adventure like never <br>
            before as we unveil our unforgettable BSCS Tour 2024 experience</p>
          </div>
        </div>

        <div class="line1">
        <h3>Highlights of the Day - [no. of days] Industry Visit</h3>
        </div>

            <div class="days-act-container">
              <div class="days">
                  <h3>DAY 1</h3>
              </div>
              

              <div class="activities">
                  <div class="picture">

                  </div>

                  <div class="desc">
                    
                  </div>
              </div>

              
            </div>  
      </div>

      <?php include 'footer.php'?>
      
    </div>


    
  </body>
  <script src="js/index.js"></script>
</html>
